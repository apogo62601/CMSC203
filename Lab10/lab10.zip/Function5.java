
public class Function5 extends Function {
	@Override
	public double fnValue(double x) {
		//  complete sin(1/x)
		return Math.sin(1 / x);
	}

	public String toString () {
		//  complete sin(1/x)
		return "sin(1/x)";
	}
}